# Mysql Workbench Dark Theme

Scintilla colors overwrite to make MySQL Workbench darker than usual.

To use this dark theme, just locate and replace the file code_editor.xml file from your MySQL Workbench _data_ directory by this one.
Just remember to make a copy of your file **BEFORE** replacing it.

## Fedora:
_/usr/share/mysql-workbench/data/code_editor.xml_

## MacOS X:
- Right click on MySQL Workbench icon.
- Click on Show Package Contents
- Open _Contents/Resources/data/code_editor.xml_

## Windows:
_C:\Program Files\MySQL\MySQL Workbench X.X\data\code_editor.xml_
